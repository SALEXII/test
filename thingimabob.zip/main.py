import requests
print("Imported 'request'.")

file_url = 'https://raw.githubusercontent.com/SALEXII/test/refs/heads/main/test.json'
print("Aligned request to " + file_url)

response = requests.get(file_url)
print("Retrieved data from " + file_url)

if response.status_code == 200:
    print("Data validated.")
    print("Proceeding with file write.")
    with open('test.json', 'wb') as file:
        file.write(response.content)
        print("Written retrieved data to file.")
        
import json
print(json.loads(open("test.json", "r").read()))